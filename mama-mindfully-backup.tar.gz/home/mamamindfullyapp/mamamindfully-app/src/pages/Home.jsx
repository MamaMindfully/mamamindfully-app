// src/pages/Home.jsx
import React from 'react'

export default function Home(){
  return <h2>Welcome to Mama Mindfully</h2>
}
